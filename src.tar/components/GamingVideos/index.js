import {Link} from 'react-router-dom'
import {
  GameItemContainer,
  GameImage,
  GameViews,
  GameName,
} from './styledComponents'
import './index.css'

const GamingVideos = props => {
  const {eachVideo} = props
  return (
    <GameItemContainer>
      <Link to={`/videos/${eachVideo.id}`} className="link-item">
        <GameImage src={eachVideo.thumbnailUrl} />
        <GameName>{eachVideo.title}</GameName>
        <GameViews>{eachVideo.viewsCount} Watching World Wide</GameViews>
      </Link>
    </GameItemContainer>
  )
}

export default GamingVideos
