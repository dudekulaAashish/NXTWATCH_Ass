import styled from 'styled-components'

export const Navbar = styled.nav`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
  width: 80vw;
  @media (min-width: 576px) and (max-width: 768px) {
    min-width: 576px;
    max-width: 768px;
  }
`

export const HeaderLogo = styled.img`
  width: 100px;
  height: 20px;
  margin-left: 10px;
  margin-right: 30px;
  @media (min-width: 576px) and (max-width: 768px) {
    width: 150px;
    height: 30px;
  }
`

export const NavMenu = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  list-style-type: none;
  margin-left: 30px;
`

export const NavLink = styled.div`
  margin-right: 20px;
`

export const NavLinkMenuLogout = styled.div`
  @media screen and (min-width: 768px) {
    display: none;
  }
`
export const NavLinkProfile = styled.div`
  @media screen and (max-width: 768px) {
    display: none;
  }
`

export const HeaderProfile = styled.img`
  width: 40px;
  height: 40px;
  margin-right: 10px;
`

export const LogoutBtn = styled.button`
  border: 1px solid #3b82f6;
  color: #3b82f6;
  padding: 5px;
  font-size: 14px;
  font-family: 'Roboto';
  width: 100px;
  margin-right: 10px;
  margin-left: 10px;
  background-color: transparent;
  font-weight: bold;
  @media screen and (max-width: 768px) {
    display: none;
  }
`
