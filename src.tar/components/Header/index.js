import {Link, withRouter} from 'react-router-dom'

import {GiHamburgerMenu} from 'react-icons/gi'
import {CgDarkMode} from 'react-icons/cg'
import {FiLogOut} from 'react-icons/fi'
import Cookies from 'js-cookie'
import ThemeContext from '../../context/ThemeContext'
import {
  NavMenu,
  NavLink,
  LogoutBtn,
  NavLinkMenuLogout,
  NavLinkProfile,
  Navbar,
  HeaderLogo,
  HeaderProfile,
} from './styledComponents'
import './index.css'

const Header = props => (
  <ThemeContext.Consumer>
    {value => {
      const {darkThemeActivated, toggleTheme} = value
      const onToggleTheme = () => {
        toggleTheme()
      }

      const {history} = props

      const onClickLogout = () => {
        Cookies.remove('jwt_token')
        history.replace('/login')
      }

      const navbarBgClassName = darkThemeActivated
        ? 'navbar-bg-dark'
        : 'navbar-bg-light'

      const iconBgColor = darkThemeActivated
        ? 'header-icon-bg-light'
        : 'header-icon-bg-dark'

      const headerLogo = darkThemeActivated
        ? 'https://assets.ccbp.in/frontend/react-js/nxt-watch-logo-dark-theme-img.png'
        : 'https://assets.ccbp.in/frontend/react-js/nxt-watch-logo-light-theme-img.png'

      return (
        <Navbar className={navbarBgClassName}>
          <HeaderLogo src={headerLogo} alt="nxt watch logo" />
          <NavMenu>
            <NavLink>
              <CgDarkMode
                className={`header-icon ${iconBgColor}`}
                data-testid="theme"
                onClick={onToggleTheme}
              />
            </NavLink>
            <Link to="/">
              <NavLink>
                <NavLinkMenuLogout>
                  <GiHamburgerMenu className={`header-icon ${iconBgColor}`} />
                </NavLinkMenuLogout>
              </NavLink>
              <NavLinkProfile>
                <HeaderProfile
                  src="https://assets.ccbp.in/frontend/react-js/nxt-watch-profile-img.png"
                  alt="profile"
                />
              </NavLinkProfile>
            </Link>
            <NavLink onClick={onClickLogout}>
              <NavLinkMenuLogout>
                <FiLogOut className={`header-icon ${iconBgColor}`} />
              </NavLinkMenuLogout>
              <LogoutBtn>Logout</LogoutBtn>
            </NavLink>
          </NavMenu>
        </Navbar>
      )
    }}
  </ThemeContext.Consumer>
)

export default withRouter(Header)
