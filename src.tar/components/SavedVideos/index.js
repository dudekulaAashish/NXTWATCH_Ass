import {RiSaveLine} from 'react-icons/ri'
import {
  SavedVideosContainer,
  SavedVideosMenuListContainer,
  SavedVideosListContainer,
  GamingBanner,
  GamingIcon,
  GamingTitle,
  SavedVideoPageList,
} from './styledComponents'

import Menu from '../Menu'
import Header from '../Header'
import SavedVideosItem from '../SavedVideoItem'
import ThemeContext from '../../context/ThemeContext'

const SavedVideos = () => (
  <ThemeContext.Consumer>
    {value => {
      const {savedVideosList} = value
      return (
        <SavedVideosContainer>
          <Header />
          <SavedVideosMenuListContainer>
            <Menu />
            <SavedVideosListContainer>
              <GamingBanner>
                <GamingIcon>
                  <RiSaveLine className="fire-icon" />
                </GamingIcon>
                <GamingTitle>Saved Videos</GamingTitle>
              </GamingBanner>
              <SavedVideoPageList>
                {savedVideosList.map(eachVideo => (
                  <SavedVideosItem eachVideo={eachVideo} key={eachVideo.id} />
                ))}
              </SavedVideoPageList>
            </SavedVideosListContainer>
          </SavedVideosMenuListContainer>
        </SavedVideosContainer>
      )
    }}
  </ThemeContext.Consumer>
)

export default SavedVideos
